using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class itemScript : MonoBehaviour
{
    AudioSource sound;
    // Start is called before the first frame update
    void Start()
    {
        sound = GetComponent<AudioSource>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            StartCoroutine(PickUp());
        }
    }

    private IEnumerator PickUp()
    {
        sound.Play();
        GetComponent<BoxCollider>().enabled = false;

        scoreController.addScore(40);
        yield return new WaitForSeconds(sound.clip.length-1.3f);
        gameObject.SetActive(false);
        itemsController.DecrementItem();
    }
}
