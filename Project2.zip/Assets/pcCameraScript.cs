using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pcCameraScript : MonoBehaviour
{
    // Start is called before the first frame update
    private Quaternion rotIni;
    public float rotVel;
    private float countRotX = 0;
    void Start()
    {
        rotVel = 220;
        rotIni = transform.localRotation;
        Cursor.lockState = CursorLockMode.Locked;
    }

    // Update is called once per frame
    void Update()
    {
        countRotX += Input.GetAxisRaw("Mouse Y") * Time.deltaTime * rotVel;
        countRotX = Mathf.Clamp(countRotX, -60, 60);
        Quaternion rotX = Quaternion.AngleAxis(countRotX, Vector3.left);
        transform.localRotation = rotIni * rotX;
    }
}
