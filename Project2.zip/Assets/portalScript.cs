using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class portalScript : MonoBehaviour

{
    public GameObject targetObject;
    public int offset;
    private AudioSource sound;

    // Start is called before the first frame update
    private void Start()
    {
        sound = GetComponent<AudioSource>();
    }

    private void OnTriggerEnter(Collider other)

    {
        if(other.tag == "Player")
        {
            sound.Play();
            Vector3 targetPostition = targetObject.transform.position;
            other.transform.position = new Vector3(targetPostition.x + offset, other.transform.position.y, targetPostition.z + offset);
            other.GetComponent<Rigidbody>().AddForce(targetObject.transform.forward * 20, ForceMode.Impulse);
        }

    }
  

}
