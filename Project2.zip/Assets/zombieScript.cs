using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class zombieScript : MonoBehaviour
{
    public AudioSource idleSound;
    public GameObject pc;
    public NavMeshAgent agent;
    public float idleSoundDelay;
    public AudioSource deathSound;
    private Animator animator;
    public GameObject[] waypoints = new GameObject[4];
    public int routeDistance = 3;
    public int chaseDistance = 15;


    private int index = 0;
    public GameObject destino;

    // Start is called before the first frame update
    void Start()
    {
        idleSoundDelay = 5f;
        InvokeRepeating("PlayIdleSound", 0.001f, idleSoundDelay);
        animator = GetComponent<Animator>();
        agent = GetComponent<NavMeshAgent>();
        Next();
    }

    // Update is called once per frame
    void Update()
    {
       
        if (Vector3.Distance(this.transform.position, destino.transform.position) < routeDistance)
        {
            Next();
        } else if(Vector3.Distance(this.transform.position, pc.transform.position) <= chaseDistance)
        {
            Chase();
        }
            
    }

    void PlayIdleSound()
    {
        idleSound.Play();
    }
 
    public void Death()
    {
        GetComponent<BoxCollider>().enabled = false;
        
        deathSound.Play();
        animator.SetBool("isDeath", true);
        agent.isStopped= true;
     
  
    }

    private void DestroySelf()
    {
        Destroy(gameObject,deathSound.clip.length);
    }

    private void Chase()
    {
        agent.destination = pc.transform.position;
    }

    private void Next()
    {
        destino = waypoints[index++];
        agent.destination = destino.transform.position;
        if (index >= 4)
        {
            index = 0;
        }
    }

}
