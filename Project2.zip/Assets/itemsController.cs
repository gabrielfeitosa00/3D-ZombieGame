using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class itemsController : MonoBehaviour
{
    // Start is called before the first frame update
    static private int itemsCount;
    static private int itemsCountUsed;
    private GameObject[] items;
    private GameObject[] ammo;
  
    void Start()
    {
        items  = GameObject.FindGameObjectsWithTag("Item");
        ammo = GameObject.FindGameObjectsWithTag("Ammo");
        itemsCount = items.Length;
        itemsCountUsed = items.Length;


    }

    // Update is called once per frame
    void Update()
    {
        if(itemsCountUsed == 0)
        {
            ResetAmmo();
            ResetItem();
            itemsCountUsed = itemsCount;
        }
    }

    static public void DecrementItem( )
    {
        itemsCountUsed = itemsCountUsed - 1;
    }

    private void ResetAmmo()
    {
        foreach(GameObject ammoItem in ammo)
        {
            ammoItem.SetActive(true);
            ammoItem.GetComponent<BoxCollider>().enabled = true;
        }
    }

    private void ResetItem()
    {
        foreach (GameObject item in items)
        {
            item.SetActive(true);
            item.GetComponent<BoxCollider>().enabled = true;
        }
    }
}
