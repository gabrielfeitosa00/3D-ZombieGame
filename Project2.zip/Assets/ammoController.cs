using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;

public class ammoController : MonoBehaviour
{
    static private int ammo = 0;
    static public AudioSource ammoAudio;
    private static GameObject txtAmmo;

    void Start()
    {
        txtAmmo = GameObject.Find("txtAmmo");

    }

    static public int GetAmmo()
    {
        return ammo;
    }

    static public void AddAmmo()
    {
        ammo += 1;
        txtAmmo.GetComponent<TMP_Text>().text = "Ammo: " + ammo;
    }

    static public void DecreaseAmmo()
    {
        ammo -= 1;
        txtAmmo.GetComponent<TMP_Text>().text = "Ammo: " + ammo;
    }

    public static void resetAmmo()
    {
        ammo = 0;
    }



}
