using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class zombieSpawner : MonoBehaviour


{
    public GameObject zombie;
    public GameObject zombieTarget;
    public GameObject[] waypoints = new GameObject[4];
    public int routeDistance = 4;
    private GameObject zombieInstance;

    // Start is called before the first frame update
    void Start()
    {
        GameObject zombieObj = Instantiate(zombie,gameObject.transform.position, Quaternion.identity);
        zombieScript script = zombieObj.GetComponent<zombieScript>();
        script.pc = zombieTarget;
        script.waypoints = waypoints;
        script.routeDistance = routeDistance;
        zombieInstance = zombieObj;
}

    // Update is called once per frame
    void Update()
    {
        int numberOfZombies = GameObject.FindGameObjectsWithTag("Enemy").Length;
        if (zombieInstance==null) {
            GameObject zombieObj = Instantiate(zombie, gameObject.transform.position, Quaternion.identity);
            zombieScript script = zombieObj.GetComponent<zombieScript>();
            script.pc = zombieTarget;
            script.waypoints = waypoints;
            script.routeDistance = routeDistance;
            zombieInstance = zombieObj;
        }
    }
 
}
