using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class scoreController : MonoBehaviour
{
    // Start is called before the first frame update
    private static float score = 0;
    private static GameObject txtScore;
    void Start()
    {
        txtScore = GameObject.Find("txtScore");
     
    }

    public static void addScore(int value)
    {
        score += value;
 
        txtScore.GetComponent<TMP_Text>().text = "Score: " + score;
        if (score % 1000 == 0)
        {
            liveController.addLive();

        }
    }

    public static void resetScore()
    {
        score = 0;
    }
}
