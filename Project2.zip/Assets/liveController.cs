using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class liveController : MonoBehaviour
{
    private static float lives = 3;
    private static GameObject txtLives;
    // Start is called before the first frame update
    void Start()
    {
        txtLives = GameObject.Find("txtLives");
    }

    public static void addLive()
    {
        lives += 1;
        txtLives.GetComponent<TMP_Text>().text = lives + "X Lives";
    }

    public static void removeLive()
    {
        lives -= 1;
        txtLives.GetComponent<TMP_Text>().text = lives + "X Lives";
    }

    public static void resetLive()
    {
        lives = 3;

    }
    public static float getLive()
    {
        return lives;
    }
}
