using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class pcScript : MonoBehaviour
{
    private Rigidbody rbd;
    public float vel;
    private Quaternion rotIni;
    public float rotVel;
    private float countRotY = 0;
    public LayerMask mask;
    public GameObject camera;
    public float shootRange;
  
    public AudioSource empty;
    public AudioSource shoot;
   

    // Start is called before the first frame update
    void Start()
    {
        rbd = GetComponent<Rigidbody>();
        vel = 10;
        rotVel = 220;
        rotIni = transform.localRotation;
        Cursor.lockState = CursorLockMode.Locked;
        shootRange = 100;
    }

    // Update is called once per frame
    void Update()
    {
        float frente = Input.GetAxis("Vertical");
        float lado = Input.GetAxis("Horizontal");

        Vector3 direcao = transform.TransformDirection(new Vector3(lado * vel, rbd.velocity.y, frente * vel));
        rbd.velocity = direcao;
        countRotY += Input.GetAxisRaw("Mouse X") * Time.deltaTime * rotVel;
        Quaternion rotY = Quaternion.AngleAxis(countRotY, Vector3.up);
        transform.localRotation = rotIni * rotY;
        Shoot();
       
    }
    private void OnCollisionEnter(Collision collision)
    {
        GameObject other = collision.gameObject;
    

     
        if (other.tag == "Enemy")

        {
          
            liveController.removeLive();
            if (liveController.getLive() == 0)
            {

                Destroy(gameObject);
                SceneManager.LoadSceneAsync(2);
                liveController.resetLive();
                scoreController.resetScore();
            }
        }
    }
   

    private void Shoot()
    {
         if (Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0))
        {
            RaycastHit hit;
            if (Physics.Raycast(
                camera.transform.position,
                camera.transform.forward,
                out hit,
                shootRange,
                mask

            ))
            {
               
                if(ammoController.GetAmmo() == 0)
                {
                    empty.Play();
                }
                else
                {
                    shoot.Play();
                    ammoController.DecreaseAmmo();
                    GameObject alvo = hit.collider.gameObject;
                    Rigidbody alvoBD = alvo.GetComponent<Rigidbody>();
                    alvoBD.AddForce(camera.transform.forward * 50);
                    if(alvo.tag == "Enemy")
                    {
                        //TODO maybe change this to use respawn
                        zombieScript targetScript = alvo.GetComponent<zombieScript>();

                        if (targetScript != null)
                        {
                            
                            targetScript.Death();
                            scoreController.addScore(20);
                        
                        }
                        
                        
                    }
                }
          
            }
        }
    }
}
